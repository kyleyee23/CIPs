#This program calculates the theoretical lensing effect of CIPs
